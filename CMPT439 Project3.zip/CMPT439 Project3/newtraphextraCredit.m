function [root, iter] = newtraphextraCredit(x0,f,tol,flag)

syms x;
format long;

func = input('Enter a non-linear equation: ');
x0 = input('Enter initial guess: ');
flag = input('Enter flag number: ');

iter = 0; tol = 0.000001; error = 100;

f_prime = diff(func,x);
fx = eval(subs(func,x,x0));

while error >= tol

    fx = eval(subs(func,x0));
    dfx = eval(subs(f_prime,x,x0));

    if fx == 0
        fprintf('x0 is the root%f\n', x0);
        fprintf('Iteration %f\n', iter);
    end

    iter = iter + 1;

    if dfx == 0
        print('invalid bracket');
        x0 = input('Enter another x0: ');
    end
    
    x1 = x0 - fx/dfx;
    
    fprintf('x0 = %f\t x1 = %f\t error = %d\t iteration = %d\n',x0,x1,error,iter);

    if flag == 1
        error = abs(x1-x0);
    elseif flag == 2
        error = abs((x1-x0)/x1);
    else
        flag = 3;
        error = abs(fx);
    end

    x0 = x1;
    
end

fprintf('Root is: %f\n', x1);
fprintf('Iteration: %f\n', iter);
fprintf('Error: %d\n', error);