//
//  main.cpp
//  Assignment 8
//
//  Created by Louie m Celiberti on 12/2/19.
//  Copyright © 2019 Louie m Celiberti. All rights reserved.
//

#include <iostream>
using namespace std;

int main(){

    //Declare the variables.
    int array[10], count[100], repeat_array[100];
    int n, j, k = 0;

    // prompt the user to enter the values
    for(int i = 0; i<10; i++){
        cout << "Enter an value: \n";
        cin >> n;

    if (n < 0 || n > 99){
        cout << "Please enter a value between 0 and 99." << endl;
    }else{
        array[i] = n;
    }
}
    
    int a_size = sizeof(array) / sizeof(array[0]);
    // checking the values in the array
    for (int i = 0; i < a_size; i++){
        for (j = 0; j < i; j++)
            if (array[i] == array[j])
                break;
        if (i == j){
            repeat_array[k] = array[i];
            k++;
        }
    }

    for (int i = 0; i < 10; i++)
        count[i] = 0;

    int size = k;

    //Check the occurences of the elements in the array

    for (int i = 0; i < size; i++){
        for (int j = 0; j < a_size; j++){
            if (repeat_array[i] == array[j])
                count[i]++;
        }
    }

    //print out the element occurence

    for (int i = 0; i < size; i++){
        if (count[i]>0){
            cout << repeat_array[i] << " occurs " << count[i] << " times" << endl;
        }
    }
    return 0;
}
