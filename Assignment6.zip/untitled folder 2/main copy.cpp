//
//  main.cpp
//  Assignment 6.2
//
//  Created by Louiem Celiberti on 11/8/19.
//  Copyright © 2019 Louiem Celiberti. All rights reserved.
//

/*
CMPT101 HW1, Assignment1.cpp
pURPOSE: input two numbers and if x is found print YES in out.txt
Programmer: Louie Celiberti
Date: 11/11/19
*/
#include <iostream>
#include <fstream>
using namespace std;


int main(int argc, const char * argv[]) {
    // insert code here...
    int x,n; // declare vaiables
    ifstream inputFile;
    ofstream outputFile;
    
    inputFile.open("in.txt"); // creates in.txt
    outputFile.open("out.txt"); // creates out.txt
    
    cout << "Enter two numbers: \n";
    inputFile >> x >> n; // user enters two numbers
    
    bool found = false; // bool value
    
    // iteration
    for(int i = 0; i <= n; i++){
        int num;
        inputFile >> num;
        if(num == x){
            found = true;
        }
        if(found){
            outputFile << "YES";  // if x is found print yes
        }else{
            outputFile << "NO"; // if isnt found print no
        }
    }
    // closing file
    inputFile.close();
    outputFile.close();
    cout << "Done.\n";
    return 0;
}
