//
//  main.cpp
//  Assignment 2.1
//
//  Created by Louie m Celiberti on 2/17/20.
//  Copyright © 2020 Louie m Celiberti. All rights reserved.
//

/*
CMPT102 HW1, Assignment2.1.cpp
Purpose: Check how many vowels and constants there are in the string
Programmer: Louie Celiberti
Date: 2/18/20
*/

#include <iostream>
using namespace std;
int main()
{
    // In the main function, the user is promted to enter a string
    // then the string is ran through an if statement which determines how many upper case and lower case vowels there are
    // after checking for the number of vowels, the if else statement checks if there are any constants
    // the string is then printed with how many vowels and constants there is
    string str;
    int vowels = 0, consonants = 0;
    cout << "Enter a string: ";
    getline(cin, str);
    for(int i = 0; i < str.length(); ++i)
    {
        if(str[i]=='a' || str[i]=='e' || str[i]=='i' ||
           str[i]=='o' || str[i]=='u' || str[i]=='A' ||
           str[i]=='E' || str[i]=='I' || str[i]=='O' ||
           str[i]=='U')
        {
            vowels+=1;
        }
        else if((str[i]>='a'&& str[i]<='z') || (str[i]>='A'&& str[i]<='Z'))
        {
            consonants+=1;
        }
    }
    cout << "Vowels: " << vowels << endl;
    cout << "Consonants: " << consonants << endl;
    return 0;
}
