//
//  main.cpp
//  Assignment 7.2
//
//  Created by Louie m Celiberti on 11/21/19.
//  Copyright © 2019 Louie m Celiberti. All rights reserved.
//

/*
CMPT101 HW7, Assignment7.2.cpp
purpose: Swap the user inputed values
Programmer: Louie Celiberti
Date: 11/21/19
*/

#include <iostream>
using namespace std;


// function prototype
void swapNum(int &, int &);

void swapNum(int &a, int &b){
    a = a^b;
    b = b^a;
    a = a^b;
}
int main(int argc, const char * argv[]) {
    
    int a,b;
    cout << "Please enter two numbers: \n";
    cin >> a >> b;
    // before swapping
    cout << "Before swapping: " << a << " " << b << endl;
    swapNum(a,b);
    // after swapping
    cout << "After swapping: " << a << " " << b << endl;
    return 0;
}
