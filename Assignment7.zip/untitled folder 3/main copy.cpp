//
//  main.cpp
//  Assignment 7.1
//
//  Created by Louie m Celiberti on 11/16/19.
//  Copyright © 2019 Louie m Celiberti. All rights reserved.
//


/*
CMPT101 HW7, Assignment7.1.cpp
purpose: return the maximum and minimum temp is user enter one of the follwing digits: 1,4,7
Programmer: Louie Celiberti
Date: 11/21/19
*/

#include <iostream>
using namespace std;

    // 1 4 7 do not work

bool containsDigit(int number, int digit){
    int remainder;
    bool status = true;
    while(number > 0){
        remainder = number % 10;
        if(remainder == digit){
            return status;
        }
        number /= 10;
    }
    return !status;
}
int main(int argc, const char * argv[]) {

    // 1 4 7 DO NOT WORK
    int temp;
    cout << "Enter the desired Temperature: \n";
    cin >> temp;
    
    // checking if the temperature does not contains 1 4 7
    if(containsDigit(temp, 1) == false && containsDigit(temp, 4) == false && containsDigit(temp, 7) == false){
        cout << "Output Temperature: " << temp << endl;
        return 0;
    }
    int min,max;
    
    min = temp;
    max = temp;
    
    // to find the min temperature, increment the value of temp
    
    while(containsDigit(min, 1) || containsDigit(min, 4) || containsDigit(min, 7))
        min--;
        cout << "Minimum temperature is: " << min << endl;
    
    // to find the max temperature, increment the value of temp
    
    while(containsDigit(max, 1) || containsDigit(max, 4) || containsDigit(max, 7))
        max++;
        cout << "Maximum temperature is: " << max << endl;
    
    return 0;
}
