//
//  main.cpp
//  Assignment 7.3
//
//  Created by Louie m Celiberti on 11/18/19.
//  Copyright © 2019 Louie m Celiberti. All rights reserved.
//

#include <iostream>
#include <iomanip>
using namespace std;

/*
CMPT101 HW7, Assignment7.3.cpp
purpose: return the highest the value of the two or three floating point numbers
Programmer: Louie Celiberti
Date: 11/21/19
*/

// Function prototypes
double max(double n1, double n2);
double max(double n1, double n2, double n3);

double max(double n1, double n2){
    
    // if n1 is greater than n2 return n2
    // else return n2
    
    if(n1 >= n2){
        return n1;
    }
    return n2;
}

double max(double n1, double n2, double n3){

    // if n1 is greater than both n2 and n3 reutrn n3
    // if n2 is greater than both n1 and n3 return n2
    // else reutrn n3
    if(n1 >= n2 && n1 >= n3){
        return n1;
    }else if(n2 >= n1 && n2 >= n3){
        return n2;
    }
    return n3;
}

int main(int argc, const char * argv[]) {
    // insert code here...
    int n;
    cout << "Enter how many floating point numbers you like to use: \n";
    cin >> n;
    // if users enters two then print find the maximum number of the two inputs
    // else return the highest of the three inputs
    if(n==2){
        double a,b;
        cout << "Enter two floating point numbers: \n";
        cin >> a >> b;
        cout << "The highest number of the two is: " << max(a,b) << endl;
    }else{
        double a,b,c;
        cout << "Enter three floating point numbers: \n";
        cin >> a >> b >> c;
        cout << "The highest number of the three is: " << max(a,b,c) << endl;
    }
    return 0;
}
